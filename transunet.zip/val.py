#! /data/cxli/miniconda3/envs/th200/bin/python
import argparse  # 用于命令行参数解析
import os  # 用于文件和目录操作
from glob import glob  # 用于获取文件路径列表
import random  # 用于生成随机数
import numpy as np  # 用于科学计算

import cv2  # OpenCV库，用于图像处理
import torch  # PyTorch深度学习框架
import torch.backends.cudnn as cudnn  # 用于加速GPU计算
import yaml  # 用于解析YAML配置文件
from albumentations.augmentations import transforms  # 用于图像增强
from albumentations.core.composition import Compose  # 用于组合多个增强操作
from sklearn.model_selection import train_test_split  # 用于划分训练和验证集
from tqdm import tqdm  # 用于显示进度条
from collections import OrderedDict  # 有序字典，用于日志记录
from thop import profile,clever_format
from thop import profile

import archs  # 模型架构定义模块
from archs import CONFIGS as CONFIGS_ViT_seg
from dataset import Dataset  # 自定义数据集类
from metrics import iou_score  # 自定义IoU评分函数
from utils import AverageMeter  # 自定义用于计算平均值的类
from albumentations import RandomRotate90, Resize  # 用于图像增强
import time  # 时间模块

from PIL import Image  # 图像处理库

def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('--name', default=None, help='model name')
    parser.add_argument('--output_dir', default='outputs', help='ouput dir')
            
    args = parser.parse_args()

    return args

def seed_torch(seed=1029):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def main():
    seed_torch()
    args = parse_args()

    # 从配置文件加载配置参数
    with open(f'{args.output_dir}/{args.name}/config.yml', 'r') as f:
        config = yaml.load(f, Loader=yaml.FullLoader)

    print('-'*20)
    for key in config.keys():
        print('%s: %s' % (key, str(config[key])))   # 打印所有配置项
    print('-'*20)

    cudnn.benchmark = True  # 启动cudnn的自动调优

    model = archs.__dict__[config['arch']](CONFIGS_ViT_seg['R50-ViT-B_16'],
                                           img_size=config['input_w'],
                                           num_classes=config['num_classes'])

    model = model.cuda()

    # 数据集和图像路径设置
    dataset_name = config['dataset']
    img_ext = '.png'

    if dataset_name == 'busi':
        mask_ext = '_mask.png'
    elif dataset_name == 'glas':
        mask_ext = '.png'
    elif dataset_name == 'cvc':
        mask_ext = '.png'
    elif dataset_name == 'glas_256':
        mask_ext = '.png'
    elif dataset_name == 'busbr':
        mask_ext = '.png'
    elif dataset_name == 'tucc':
        mask_ext = '.png'

    # Data loading code
    img_ids = sorted(glob(os.path.join(config['data_dir'], config['dataset'], 'images', '*' + img_ext)))
    # img_ids.sort()---仅提取图像名称
    img_ids = [os.path.splitext(os.path.basename(p))[0] for p in img_ids]

    _, val_img_ids = train_test_split(img_ids, test_size=0.2, random_state=config['dataseed'])

    # 加载模型权重
    ckpt = torch.load(f'{args.output_dir}/{args.name}/model.pth')

    try:        
        model.load_state_dict(ckpt)
    except:
        # 如果模型加载失败，输出预训练模型和当前模型的差异
        print("Pretrained model keys:", ckpt.keys())
        print("Current model keys:", model.state_dict().keys())

        pretrained_dict = {k: v for k, v in ckpt.items() if k in model.state_dict()}
        current_dict = model.state_dict()
        diff_keys = set(current_dict.keys()) - set(pretrained_dict.keys())

        print("Difference in model keys:")
        for key in diff_keys:
            print(f"Key: {key}")

        model.load_state_dict(ckpt, strict=False)

    # Get the parameters number
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Total number of parameters: {total_params}")

    x = torch.randn(1, 3, 256, 256).cuda()
    flops, params = profile(model, inputs=(x,))
    flops, params = clever_format([flops, params], "%.3f")
    print(params)
    print(flops)
        
    model.eval()

    val_transform = Compose([
        Resize(config['input_h'], config['input_w']),
        transforms.Normalize(),
    ])

    val_dataset = Dataset(
        img_ids=val_img_ids,
        img_dir=os.path.join(config['data_dir'], config['dataset'], 'images'),
        mask_dir=os.path.join(config['data_dir'], config['dataset'], 'masks'),
        img_ext=img_ext,
        mask_ext=mask_ext,
        num_classes=config['num_classes'],
        transform=val_transform)
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        drop_last=False)

    iou_avg_meter = AverageMeter()
    dice_avg_meter = AverageMeter()
    hd95_avg_meter = AverageMeter()

    with torch.no_grad():
        for input, target, meta in tqdm(val_loader, total=len(val_loader)):
            input = input.cuda()
            target = target.cuda()
            model = model.cuda()
            # compute output
            output = model(input)

            iou, dice, hd95_ = iou_score(output, target)
            iou_avg_meter.update(iou, input.size(0))
            dice_avg_meter.update(dice, input.size(0))
            hd95_avg_meter.update(hd95_, input.size(0))

            output = torch.sigmoid(output).cpu().numpy()
            output[output>=0.5]=1
            output[output<0.5]=0

            os.makedirs(os.path.join(args.output_dir, args.name, 'out_val'), exist_ok=True)
            for pred, img_id in zip(output, meta['img_id']):
                pred_np = pred[0].astype(np.uint8)
                pred_np = pred_np * 255
                img = Image.fromarray(pred_np, 'L')
                img.save(os.path.join(args.output_dir, args.name, 'out_val/{}.jpg'.format(img_id)))

    
    print(config['name'])
    print('IoU: %.4f' % iou_avg_meter.avg)
    print('Dice: %.4f' % dice_avg_meter.avg)
    print('HD95: %.4f' % hd95_avg_meter.avg)



if __name__ == '__main__':
    main()
