dataset=busi
input_size=256
python train.py --name busi_1
python val.py --name busi_1

dataset=glas
input_size=512
python train.py --dataset glas --input_w 512 --input_h 512 --name glas_1
python val.py --name glas_1

dataset = glas_256
python train.py --dataset glas_256 --name glas_1
python val.py --name glas_1

dataset=cvc
input_size=256
python train.py --dataset cvc --name cvc_1
python val.py --name cvc_1