import argparse
import os
from collections import OrderedDict
from glob import glob
import random
import numpy as np

import pandas as pd
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.optim as optim
import yaml

from albumentations.augmentations import transforms
from albumentations.augmentations import geometric

from albumentations.core.composition import Compose, OneOf
from sklearn.model_selection import train_test_split
from torch.optim import lr_scheduler
from tqdm import tqdm
from albumentations import RandomRotate90, Resize

import archs
from archs import CONFIGS as CONFIGS_ViT_seg

import losses
from dataset import Dataset

from metrics import iou_score, indicators

from utils import AverageMeter, str2bool

from tensorboardX import SummaryWriter  # 用于记录训练过程到tensorboard

import shutil
import os
import subprocess

from pdb import set_trace as st  # 用于调试时的断点

LOSS_NAMES = losses.__all__
LOSS_NAMES.append('BCEWithLogitsLoss')


# 将字符串转化为列表
def list_type(s):
    str_list = s.split(',')
    int_list = [int(a) for a in str_list]
    return int_list


# 解析命令行参数
def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('--name', default=None,
                        help='model name: (default: arch+timestamp)')
    parser.add_argument('--epochs', default=400, type=int, metavar='N',
                        help='number of total epochs to run')
    parser.add_argument('-b', '--batch_size', default=16, type=int,
                        metavar='N', help='mini-batch size (default: 16)')

    parser.add_argument('--dataseed', default=2981, type=int,
                        help='')

    # model
    parser.add_argument('--arch', '-a', metavar='ARCH', default='VisionTransformer')

    parser.add_argument('--deep_supervision', default=False, type=str2bool)
    parser.add_argument('--input_channels', default=3, type=int,
                        help='input channels')
    parser.add_argument('--num_classes', default=1, type=int,
                        help='number of classes')
    parser.add_argument('--input_w', default=256, type=int,
                        help='image width')
    parser.add_argument('--input_h', default=256, type=int,
                        help='image height')
    parser.add_argument('--input_list', type=list_type, default=[32,64,128,256,512])

    # loss
    parser.add_argument('--loss', default='BCEDiceLoss',
                        choices=LOSS_NAMES,
                        help='loss: ' +
                             ' | '.join(LOSS_NAMES) +
                             ' (default: BCEDiceLoss)')

    # dataset
    parser.add_argument('--dataset', default='busi', help='dataset name')
    parser.add_argument('--data_dir', default='inputs', help='dataset dir')

    parser.add_argument('--output_dir', default='outputs', help='ouput dir')

    # optimizer---更新模型参数，使损失函数最小化
    # Adam 基于梯度的自适应优化器，有更快的收敛速度，且对学习率不那么敏感
    # SGD 随机梯度下降
    parser.add_argument('--optimizer', default='Adam',
                        choices=['Adam', 'SGD'],
                        help='loss: ' +
                             ' | '.join(['Adam', 'SGD']) +
                             ' (default: Adam)')
    # 学习率决定每次更新时参数调整的幅度
    parser.add_argument('--lr', '--learning_rate', default=1e-4, type=float,
                        metavar='LR', help='initial learning rate')
    # SGD优化器的动量。动量的作用是加速 SGD 在相关方向上的收敛，并抑制噪声的干扰
    parser.add_argument('--momentum', default=0.9, type=float,
                        help='momentum')
    # 权重衰减（L2正则化），值越大，正则化越强
    parser.add_argument('--weight_decay', default=1e-4, type=float,
                        help='weight decay')
    # 用来决定是否使用Nesterov动量加速，在SGD中Nesterov动量比普通动量方法有更好的收敛效果，特别是在非凸优化问题中
    parser.add_argument('--nesterov', default=False, type=str2bool,
                        help='nesterov')
    # KAN层学习率和权重衰减
    parser.add_argument('--kan_lr', default=1e-2, type=float,
                        metavar='LR', help='initial learning rate')
    parser.add_argument('--kan_weight_decay', default=1e-4, type=float,
                        help='weight decay')

    # scheduler---学习率调度器，控制在训练过程中如何动态调整学习率
    # 1、CosineAnnealingLR：一种基于余弦退火的学习率调度方法，它会在训练过程中逐渐减小学习率，接近训练结束时学习率非常小。
    # 2、ReduceLROnPlateau：当验证集的性能（如损失）在若干个周期内没有改善时，减小学习率。适用于收敛较慢的情况。
    # 3、MultiStepLR：按照预定的 milestones 列表减小学习率。例如，在训练的某些特定周期后降低学习率。
    # 4、ConstantLR：保持学习率不变。
    parser.add_argument('--scheduler', default='CosineAnnealingLR',
                        choices=['CosineAnnealingLR', 'ReduceLROnPlateau', 'MultiStepLR', 'ConstantLR'])
    parser.add_argument('--min_lr', default=1e-5, type=float,
                        help='minimum learning rate')

    parser.add_argument('--factor', default=0.1, type=float)  # 2：学习率减少的倍数
    parser.add_argument('--patience', default=2, type=int)  # 2：耐心值，即连续几个 epoch 没有提升时才会触发学习率的调整
    parser.add_argument('--milestones', default='1,2', type=str)  # 3：定义学习率调整的周期
    parser.add_argument('--gamma', default=2 / 3, type=float)  # 3：学习率减少的倍数

    # 提前停止的轮次，当训练中的验证损失或其他指标在若干轮内没有改进时，训练会提前停止，-1 表示没有启用提前停止
    parser.add_argument('--early_stopping', default=-1, type=int,
                        metavar='N', help='early stopping (default: -1)')
    # 指定配置文件的路径
    parser.add_argument('--cfg', type=str, metavar="FILE", help='path to config file', )
    # 数据加载的并行度
    parser.add_argument('--num_workers', default=4, type=int)
    # 是否启用KAN
    parser.add_argument('--no_kan', action='store_true')

    config = parser.parse_args()

    return config


def train(config, train_loader, model, criterion, optimizer):
    # AverageMeter 类通常用于计算和存储指标（如损失、准确率等）的平均值
    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter()}

    model.train()

    pbar = tqdm(total=len(train_loader))  # 创建一个进度条
    # 将输入数据和目标标签移动到 GPU 上
    for input, target, _ in train_loader:
        input = input.cuda()
        target = target.cuda()

        # compute output---前向传播，是否启用深度监督
        if config['deep_supervision']:
            outputs = model(input)
            loss = 0
            for output in outputs:
                loss += criterion(output, target)
            loss /= len(outputs)

            iou, dice, _ = iou_score(outputs[-1], target)
            iou_, dice_, hd_, hd95_, recall_, specificity_, precision_ = indicators(outputs[-1], target)

        else:
            output = model(input)
            loss = criterion(output, target)
            iou, dice, _ = iou_score(output, target)
            iou_, dice_, hd_, hd95_, recall_, specificity_, precision_ = indicators(output, target)

        # compute gradient and do optimizing step---反向传播和优化
        optimizer.zero_grad()  # 将优化器中的梯度缓存清空，因为默认情况下，PyTorch 会在每次反向传播时累积梯度
        loss.backward()
        optimizer.step()

        avg_meters['loss'].update(loss.item(), input.size(0))  # loss.item() 获取当前批次的损失值，input.size(0) 是当前批次的样本数量
        avg_meters['iou'].update(iou, input.size(0))

        # 更新进度条
        postfix = OrderedDict([
            ('loss', avg_meters['loss'].avg),
            ('iou', avg_meters['iou'].avg),
        ])
        pbar.set_postfix(postfix)
        pbar.update(1)
    pbar.close()  # 所有训练完成之后关闭进度条

    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg)])


# 验证过程无需进行梯度更新（反向传播）
def validate(config, val_loader, model, criterion):
    avg_meters = {'loss': AverageMeter(),
                  'iou': AverageMeter(),
                  'dice': AverageMeter()}

    # switch to evaluate mode
    model.eval()
    # 禁用梯度计算
    with torch.no_grad():
        pbar = tqdm(total=len(val_loader))
        for input, target, _ in val_loader:
            input = input.cuda()
            target = target.cuda()

            # compute output
            if config['deep_supervision']:
                outputs = model(input)
                loss = 0
                for output in outputs:
                    loss += criterion(output, target)
                loss /= len(outputs)
                iou, dice, _ = iou_score(outputs[-1], target)
            else:
                output = model(input)
                loss = criterion(output, target)
                iou, dice, _ = iou_score(output, target)
            # 更新评估指标
            avg_meters['loss'].update(loss.item(), input.size(0))
            avg_meters['iou'].update(iou, input.size(0))
            avg_meters['dice'].update(dice, input.size(0))

            postfix = OrderedDict([
                ('loss', avg_meters['loss'].avg),
                ('iou', avg_meters['iou'].avg),
                ('dice', avg_meters['dice'].avg)
            ])
            pbar.set_postfix(postfix)
            pbar.update(1)
        pbar.close()

    return OrderedDict([('loss', avg_meters['loss'].avg),
                        ('iou', avg_meters['iou'].avg),
                        ('dice', avg_meters['dice'].avg)])


# 设置随机种子以保证结果可复现
def seed_torch(seed=1029):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def main():
    seed_torch()  # 设置随机种子
    config = vars(parse_args())  # 解析命令行参数，返回一个字典
    exp_name = config.get('name')  # 获取实验名称
    output_dir = config.get('output_dir')  # 获取输出目录

    my_writer = SummaryWriter(f'{output_dir}/{exp_name}')  # 初始化TensorBoard日志记录器

    # 如果没有给定实验名称，则根据模型架构和数据集名称生成名称
    if config['name'] is None:
        if config['deep_supervision']:
            config['name'] = '%s_%s_wDS' % (config['dataset'], config['arch'])
        else:
            config['name'] = '%s_%s_woDS' % (config['dataset'], config['arch'])

    os.makedirs(f'{output_dir}/{exp_name}', exist_ok=True)  # 创建保存训练结果的输出目录

    print('-' * 20)
    for key in config:
        print('%s: %s' % (key, config[key]))  # 打印所有配置参数
    print('-' * 20)

    # 将配置参数保存为YAML格式的文件
    with open(f'{output_dir}/{exp_name}/config.yml', 'w') as f:
        yaml.dump(config, f)

    # define loss function (criterion)
    if config['loss'] == 'BCEWithLogitsLoss':
        criterion = nn.BCEWithLogitsLoss().cuda()
    else:
        criterion = losses.__dict__[config['loss']]().cuda()

    cudnn.benchmark = True  # 让cudnn根据输入的尺寸动态选择算法

    # create model
    model = archs.__dict__[config['arch']](CONFIGS_ViT_seg['R50-ViT-B_16'],
                                           img_size=config['input_w'],
                                           num_classes=config['num_classes'])
    print(model)

    model = model.cuda()

    # 初始化优化器
    param_groups = []
    kan_fc_params = []
    other_params = []

    for name, param in model.named_parameters():
        # print(name, "=>", param.shape)
        # 对模型的所有参数分组，分别设置不同的学习率和权重衰减，Kan层使用较大的学习率
        if 'kan' in name.lower() and 'fc' in name.lower():  # higher lr for kan layers
            # kan_fc_params.append(name)
            param_groups.append({'params': param, 'lr': config['kan_lr'], 'weight_decay': config['kan_weight_decay']})
        else:
            # other_params.append(name)
            param_groups.append({'params': param, 'lr': config['lr'], 'weight_decay': config['weight_decay']})

    # 选择优化器
    if config['optimizer'] == 'Adam':
        optimizer = optim.Adam(param_groups)
    elif config['optimizer'] == 'SGD':
        optimizer = optim.SGD(params, lr=config['lr'], momentum=config['momentum'], nesterov=config['nesterov'],
                              weight_decay=config['weight_decay'])
    else:
        raise NotImplementedError

    if config['scheduler'] == 'CosineAnnealingLR':
        scheduler = lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=config['epochs'], eta_min=config['min_lr'])
    elif config['scheduler'] == 'ReduceLROnPlateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, factor=config['factor'], patience=config['patience'],
                                                   verbose=1, min_lr=config['min_lr'])
    elif config['scheduler'] == 'MultiStepLR':
        scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=[int(e) for e in config['milestones'].split(',')],
                                             gamma=config['gamma'])
    elif config['scheduler'] == 'ConstantLR':
        scheduler = None
    else:
        raise NotImplementedError

    # 将训练脚本和模型架构保存到输出目录
    shutil.copy2('train.py', f'{output_dir}/{exp_name}/')
    shutil.copy2('archs.py', f'{output_dir}/{exp_name}/')

    dataset_name = config['dataset']
    img_ext = '.png'

    if dataset_name == 'busi':
        mask_ext = '_mask.png'
    elif dataset_name == 'glas':
        mask_ext = '.png'
    elif dataset_name == 'cvc':
        mask_ext = '.png'
    elif dataset_name == 'glas_256':
        mask_ext = '.png'
    elif dataset_name == 'busbr':
        mask_ext = '.png'
    elif dataset_name == 'tucc':
        mask_ext = '.png'

    # Data loading code
    img_ids = sorted(glob(os.path.join(config['data_dir'], config['dataset'], 'images', '*' + img_ext)))
    img_ids = [os.path.splitext(os.path.basename(p))[0] for p in img_ids]

    train_img_ids, val_img_ids = train_test_split(img_ids, test_size=0.2, random_state=config['dataseed'])

    # 定义训练和验证的图像增强操作
    train_transform = Compose([
        RandomRotate90(),
        geometric.transforms.Flip(),
        Resize(config['input_h'], config['input_w']),
        transforms.Normalize(),
    ])

    # 验证集只进行缩放和归一化
    val_transform = Compose([
        Resize(config['input_h'], config['input_w']),
        transforms.Normalize(),
    ])

    # 创建训练和验证数据集
    train_dataset = Dataset(
        img_ids=train_img_ids,
        img_dir=os.path.join(config['data_dir'], config['dataset'], 'images'),
        mask_dir=os.path.join(config['data_dir'], config['dataset'], 'masks'),
        img_ext=img_ext,
        mask_ext=mask_ext,
        num_classes=config['num_classes'],
        transform=train_transform)
    val_dataset = Dataset(
        img_ids=val_img_ids,
        img_dir=os.path.join(config['data_dir'], config['dataset'], 'images'),
        mask_dir=os.path.join(config['data_dir'], config['dataset'], 'masks'),
        img_ext=img_ext,
        mask_ext=mask_ext,
        num_classes=config['num_classes'],
        transform=val_transform)

    # 创建数据加载器
    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=config['num_workers'],
        drop_last=True)
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        drop_last=False)

    log = OrderedDict([
        ('epoch', []),
        ('lr', []),
        ('loss', []),
        ('iou', []),
        ('val_loss', []),
        ('val_iou', []),
        ('val_dice', []),
    ])

    best_iou = 0
    best_dice = 0
    trigger = 0

    # 开始训练和验证循环
    for epoch in range(config['epochs']):
        print('Epoch [%d/%d]' % (epoch, config['epochs']))

        # train for one epoch
        train_log = train(config, train_loader, model, criterion, optimizer)
        # evaluate on validation set
        val_log = validate(config, val_loader, model, criterion)

        # 学习率调度
        if config['scheduler'] == 'CosineAnnealingLR':
            scheduler.step()
        elif config['scheduler'] == 'ReduceLROnPlateau':
            scheduler.step(val_log['loss'])

        print('loss %.4f - iou %.4f - val_loss %.4f - val_iou %.4f'
              % (train_log['loss'], train_log['iou'], val_log['loss'], val_log['iou']))

        log['epoch'].append(epoch)
        log['lr'].append(config['lr'])
        log['loss'].append(train_log['loss'])
        log['iou'].append(train_log['iou'])
        log['val_loss'].append(val_log['loss'])
        log['val_iou'].append(val_log['iou'])
        log['val_dice'].append(val_log['dice'])

        pd.DataFrame(log).to_csv(f'{output_dir}/{exp_name}/log.csv', index=False)
        # 将训练和验证的指标添加到TensorBoard
        my_writer.add_scalar('train/loss', train_log['loss'], global_step=epoch)
        my_writer.add_scalar('train/iou', train_log['iou'], global_step=epoch)
        my_writer.add_scalar('val/loss', val_log['loss'], global_step=epoch)
        my_writer.add_scalar('val/iou', val_log['iou'], global_step=epoch)
        my_writer.add_scalar('val/dice', val_log['dice'], global_step=epoch)

        my_writer.add_scalar('val/best_iou_value', best_iou, global_step=epoch)
        my_writer.add_scalar('val/best_dice_value', best_dice, global_step=epoch)

        trigger += 1

        # 如果当前验证IoU比最佳IoU高，则保存当前模型
        if val_log['iou'] > best_iou:
            torch.save(model.state_dict(), f'{output_dir}/{exp_name}/model.pth')
            best_iou = val_log['iou']
            best_dice = val_log['dice']
            print("=> saved best model")
            print('IoU: %.4f' % best_iou)
            print('Dice: %.4f' % best_dice)
            trigger = 0

        # early stopping
        if config['early_stopping'] >= 0 and trigger >= config['early_stopping']:
            print("=> early stopping")
            break

        torch.cuda.empty_cache()


if __name__ == '__main__':
    main()
