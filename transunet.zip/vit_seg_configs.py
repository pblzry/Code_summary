import ml_collections       # 用于配置管理的python库，以字典的形式管理和存储配置信息


def get_b16_config():
    """Returns the ViT-B/16 configuration."""
    # 用于配置Vision Transformer (ViT) B/16模型的字典结构
    config = ml_collections.ConfigDict()
    config.patches = ml_collections.ConfigDict({'size': (16, 16)})      # 用于配置如何将图像分割成patches，块大小是16*16
    config.hidden_size = 768                                            # 隐藏层大小：768
    config.transformer = ml_collections.ConfigDict()                    # 用于配置Transformer模型的具体参数
    config.transformer.mlp_dim = 3072                                  # transformer中mlp的维度 原：3072
    config.transformer.num_heads = 12                                    # 多头注意力机制中的头数 原：12
    config.transformer.num_layers = 12                                  # Transformer的层数
    config.transformer.attention_dropout_rate = 0.0                     # 分别用于注意力机制
    config.transformer.dropout_rate = 0.1                               # 和Transformer层中的dropout比率，用于防止过拟合

    config.classifier = 'seg'
    config.representation_size = None
    config.resnet_pretrained_path = None            # 表示不使用ResNet预训练模型
    config.pretrained_path = './model/vit_checkpoint/imagenet21k/ViT-B_16.npz'      # 预训练模型的保存路径
    config.patch_size = 16                       # 图像块的大小

    config.decoder_channels = (256, 128, 64, 16)
    config.n_classes = 1
    config.activation = 'softmax'
    return config


def get_testing():
    """Returns a minimal configuration for testing."""
    # 返回一个用于测试的最小配置
    config = ml_collections.ConfigDict()
    config.patches = ml_collections.ConfigDict({'size': (16, 16)})
    config.hidden_size = 1
    config.transformer = ml_collections.ConfigDict()
    config.transformer.mlp_dim = 1
    config.transformer.num_heads = 1
    config.transformer.num_layers = 1
    config.transformer.attention_dropout_rate = 0.0
    config.transformer.dropout_rate = 0.1
    config.classifier = 'token'
    config.representation_size = None
    return config


def get_r50_b16_config():
    """Returns the Resnet50 + ViT-B/16 configuration."""
    # 返回一个结合了 ResNet50 和 ViT-B/16 的配置
    config = get_b16_config()                       # 获取vitb16的基础配置
    config.patches.grid = (16, 16)                  # 网格大小为16*16（源码在train.py根据patch_size进行了修改）
    config.resnet = ml_collections.ConfigDict()     # 创建一个新的配置字典用于存储ResNet的配置
    config.resnet.num_layers = (3, 4, 9)            # ResNet50 中不同阶段的卷积层数
    config.resnet.width_factor = 1                  # 控制 ResNet 宽度（即特征图的通道数）的缩放因子，1即没有缩放

    config.classifier = 'seg'                       # 分类器类型：分割
    config.pretrained_path = './model/vit_checkpoint/imagenet21k/R50+ViT-B_16.npz'  # 预训练模型路径
    config.decoder_channels = (256, 128, 64, 16)    # 解码器各层通道数
    config.skip_channels = [512, 256, 64, 16]       # 跳跃连接各层通道数
    config.n_classes = 1                            # 模型输出类别为1 (源码在train.py改为9）
    config.n_skip = 3                               # 跳跃链接的数量（源码在train.py改为3）
    config.activation = 'softmax'                   # 激活函数为softmax

    return config


def get_b32_config():
    """Returns the ViT-B/32 configuration."""
    config = get_b16_config()
    config.patches.size = (32, 32)
    config.pretrained_path = './model/vit_checkpoint/imagenet21k/ViT-B_32.npz'
    return config


def get_l16_config():
    """Returns the ViT-L/16 configuration."""
    config = ml_collections.ConfigDict()
    config.patches = ml_collections.ConfigDict({'size': (16, 16)})
    config.hidden_size = 1024
    config.transformer = ml_collections.ConfigDict()
    config.transformer.mlp_dim = 4096
    config.transformer.num_heads = 16
    config.transformer.num_layers = 24
    config.transformer.attention_dropout_rate = 0.0
    config.transformer.dropout_rate = 0.1
    config.representation_size = None

    # custom
    config.classifier = 'seg'
    config.resnet_pretrained_path = None
    config.pretrained_path = './model/vit_checkpoint/imagenet21k/ViT-L_16.npz'
    config.decoder_channels = (256, 128, 64, 16)
    config.n_classes = 2
    config.activation = 'softmax'
    return config


def get_r50_l16_config():
    """Returns the Resnet50 + ViT-L/16 configuration. customized """
    config = get_l16_config()
    config.patches.grid = (16, 16)
    config.resnet = ml_collections.ConfigDict()
    config.resnet.num_layers = (3, 4, 9)
    config.resnet.width_factor = 1

    config.classifier = 'seg'
    config.resnet_pretrained_path = './model/vit_checkpoint/imagenet21k/R50+ViT-B_16.npz'
    config.decoder_channels = (256, 128, 64, 16)
    config.skip_channels = [512, 256, 64, 16]
    config.n_classes = 2
    config.activation = 'softmax'
    return config


def get_l32_config():
    """Returns the ViT-L/32 configuration."""
    config = get_l16_config()
    config.patches.size = (32, 32)
    return config


def get_h14_config():
    """Returns the ViT-L/16 configuration."""
    config = ml_collections.ConfigDict()
    config.patches = ml_collections.ConfigDict({'size': (14, 14)})
    config.hidden_size = 1280
    config.transformer = ml_collections.ConfigDict()
    config.transformer.mlp_dim = 5120
    config.transformer.num_heads = 16
    config.transformer.num_layers = 32
    config.transformer.attention_dropout_rate = 0.0
    config.transformer.dropout_rate = 0.1
    config.classifier = 'token'
    config.representation_size = None

    return config
