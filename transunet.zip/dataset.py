import os

import cv2
import numpy as np
import torch
import torch.utils.data

# 加载图像和对应的掩膜
class Dataset(torch.utils.data.Dataset):
    def __init__(self, img_ids, img_dir, mask_dir, img_ext, mask_ext, num_classes, transform=None):
        """
        Args:
            img_ids (list): Image ids.
            img_dir: Image file directory.
            mask_dir: Mask file directory.
            img_ext (str): Image file extension.
            mask_ext (str): Mask file extension.
            num_classes (int): Number of classes.
            transform (Compose, optional): Compose transforms of albumentations. Defaults to None.

        Note:
            Make sure to put the files as the following structure:
            <dataset name>
            ├── images
            |   ├── 0a7e06.jpg
            │   ├── 0aab0a.jpg
            │   ├── 0b1761.jpg
            │   ├── ...
            |
            └── masks
                ├── 0
                |   ├── 0a7e06.png
                |   ├── 0aab0a.png
                |   ├── 0b1761.png
                |   ├── ...
                |
                ├── 1
                |   ├── 0a7e06.png
                |   ├── 0aab0a.png
                |   ├── 0b1761.png
                |   ├── ...
                ...
        """
        # 初始化类时，接受数据集参数，包括图像 ID 列表、图像目录、掩膜目录、图像和掩膜扩展名、类别数、和可选的图像变换
        self.img_ids = img_ids
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.img_ext = img_ext
        self.mask_ext = mask_ext
        self.num_classes = num_classes
        self.transform = transform

    def __len__(self):
        # # 返回数据集的大小，即图像 ID 的数量
        return len(self.img_ids)

    def __getitem__(self, idx):
        # 根据给定的索引获取图像和掩膜。

        # 获取图像 ID
        img_id = self.img_ids[idx]

        # 读取图像文件，图像路径由图像目录、图像 ID 和扩展名拼接得到
        img = cv2.imread(os.path.join(self.img_dir, img_id + self.img_ext))

        # 初始化一个空的列表，用于存储每个类的掩膜。
        mask = []
        # 为每个类（从0到num_classes-1）读取对应的掩膜，并将其加入到 mask 列表中
        for i in range(self.num_classes):

            # print(os.path.join(self.mask_dir, str(i),
            #             img_id + self.mask_ext))

            # 拼接掩膜路径，路径包括掩膜目录、类别编号（作为子目录）和图像 ID 及其扩展名
            mask.append(cv2.imread(os.path.join(self.mask_dir, str(i),
                        img_id + self.mask_ext), cv2.IMREAD_GRAYSCALE)[..., None])
        # 将掩膜列表拼接成一个多通道的掩膜图像
        mask = np.dstack(mask)

        # 如果指定了图像增强（transform），应用该增强
        if self.transform is not None:
            # 使用传入的变换（如 albumentations）对图像和掩膜进行增强
            augmented = self.transform(image=img, mask=mask)
            img = augmented['image']
            mask = augmented['mask']

            # 对图像进行归一化处理，将像素值缩放到 [0, 1] 范围内
            img = img.astype('float32') / 255
            # 调整图像维度顺序，转换为 (C, H, W) 格式，以适应 PyTorch 的要求
            img = img.transpose(2, 0, 1)

            # 对掩膜进行归一化处理，并转换为 [0, 1] 范围内
            mask = mask.astype('float32') / 255
            # 调整掩膜维度顺序，转换为 (C, H, W) 格式
            mask = mask.transpose(2, 0, 1)

            # 如果掩膜的最大值小于 1，意味着没有目标（全背景），则将所有掩膜值设置为 1
            if mask.max() < 1:
                mask[mask > 0] = 1.0

            # 确保返回的数据类型是 PyTorch 张量
            img = torch.tensor(img, dtype=torch.float32)
            mask = torch.tensor(mask, dtype=torch.float32)

            # 返回图像、掩膜和图像 ID 的字典
            return img, mask, {'img_id': img_id}